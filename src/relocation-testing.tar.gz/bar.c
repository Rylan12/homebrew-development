int bar(void) { return 1; }
